# ===============================
# 🐍 PYTHON QUEST
# 2D обучающая игра для школьников
# ===============================

import time

def slow_print(text):
    for char in text:
        print(char, end="", flush=True)
        time.sleep(0.02)
    print()

def separator():
    print("\n" + "=" * 40 + "\n")

def wait():
    input("Нажми Enter, чтобы продолжить...")

# ===============================
# УРОВЕНЬ 1
# ===============================
def level_1():
    separator()
    slow_print("УРОВЕНЬ 1: Пробуждение в Кодландии")
    slow_print("ТЕОРИЯ:")
    slow_print("Команда print() выводит текст на экран.")
    slow_print('Пример: print("Привет, мир!")')
    wait()

    separator()
    slow_print("ЗАДАНИЕ:")
    slow_print("Выведи текст: Добро пожаловать в Python Quest!")
    answer = input("Введи команду print(): ")

    if "Добро пожаловать в Python Quest!" in answer:
        slow_print("✅ Верно! Ворота открыты.")
        return True
    else:
        slow_print("❌ Неверно. Попробуй снова.")
        return level_1()

# ===============================
# УРОВЕНЬ 2
# ===============================
def level_2():
    separator()
    slow_print("УРОВЕНЬ 2: Кристаллы переменных")
    slow_print("ТЕОРИЯ:")
    slow_print("Переменные хранят данные.")
    slow_print("Пример: energy = 10")
    wait()

    separator()
    slow_print("ЗАДАНИЕ:")
    slow_print("Создай переменную energy со значением 15")
    code = input("Введи код: ")

    try:
        local_vars = {}
        exec(code, {}, local_vars)
        if local_vars.get("energy") == 15:
            slow_print("✅ Отлично! Кристалл активирован.")
            return True
        else:
            slow_print("❌ Переменная создана неверно.")
            return level_2()
    except:
        slow_print("❌ Ошибка в коде.")
        return level_2()

# ===============================
# УРОВЕНЬ 3
# ===============================
def level_3():
    separator()
    slow_print("УРОВЕНЬ 3: Лес условий")
    slow_print("ТЕОРИЯ:")
    slow_print("Иногда в игре условие уже выполнено.")
    slow_print("Если условие верное — нужно просто вывести текст.")
    wait()

    separator()
    slow_print("ЗАДАНИЕ:")
    slow_print("У героя lives = 6 (это больше 5).")
    slow_print("Просто выведи текст: Мост пройден")
    slow_print("❗ Пиши В ОДНУ СТРОКУ")

    code = input("Введи команду print(): ").strip()

    if code == "":
        slow_print("❌ Пустой ввод. Попробуй ещё раз.")
        return level_3()

    try:
        output = []

        def fake_print(text):
            output.append(str(text))

        exec(code, {"print": fake_print})

        if "Мост пройден" in output:
            slow_print("✅ Верно! Ты прошёл мост.")
            return True
        else:
            slow_print("❌ Текст неверный.")
            return level_3()

    except:
        slow_print("❌ Ошибка в команде print.")
        return level_3()
# ===============================
# УРОВЕНЬ 4
# ===============================
def level_4():
    separator()
    slow_print("УРОВЕНЬ 4: Дорога шагов")
    slow_print("ТЕОРИЯ:")
    slow_print("Иногда герою нужно делать шаги вперёд.")
    slow_print("Мы начинаем с самого простого.")
    slow_print("Нужно просто вывести одно слово.")
    wait()

    separator()
    slow_print("ЗАДАНИЕ:")
    slow_print("Выведи слово: Шаг")
    slow_print("❗ Используй одну команду print")

    code = input("Введи команду print(): ").strip()

    if code == "":
        slow_print("❌ Пустой ввод. Попробуй ещё раз.")
        return level_4()

    try:
        output = []

        def fake_print(text):
            output.append(str(text))

        exec(code, {"print": fake_print})

        if "Шаг" in output:
            slow_print("✅ Отлично! Герой сделал шаг.")
            slow_print("➡➡➡ Герой сделал ещё шаги сам!")
            return True
        else:
            slow_print("❌ Нужно вывести именно слово: Шаг")
            return level_4()

    except:
        slow_print("❌ Ошибка в команде print.")
        return level_4()

# ===============================
# УРОВЕНЬ 5
# ===============================
def level_5():
    separator()
    slow_print("УРОВЕНЬ 5: Финальная битва")
    slow_print("ТЕОРИЯ:")
    slow_print("Иногда достаточно сказать правильные слова.")
    slow_print("Мы используем команду print.")
    wait()

    separator()
    slow_print("ЗАДАНИЕ:")
    slow_print("Выведи текст: Баг побеждён")
    slow_print("❗ Используй одну строку")

    code = input("Введи команду print(): ").strip()

    if code == "":
        slow_print("❌ Пустой ввод. Попробуй ещё раз.")
        return level_5()

    try:
        output = []

        def fake_print(text):
            output.append(str(text))

        exec(code, {"print": fake_print})

        if "Баг побеждён" in output:
            slow_print("🐉 Победа!")
            slow_print("🎉 Ты прошёл Python Quest!")
            return True
        else:
            slow_print("❌ Текст неверный.")
            return level_5()

    except:
        slow_print("❌ Ошибка в команде print.")
        return level_5()

# ===============================
# ИГРА
# ===============================
def start_game():
    separator()
    slow_print("🐍 PYTHON QUEST 🐍")
    slow_print("Обучающая игра для юных программистов")
    wait()

    level_1()
    level_2()
    level_3()
    level_4()
    level_5()

    separator()
    slow_print("🎉 ПОЗДРАВЛЯЕМ!")
    slow_print("Ты прошёл Python Quest и победил баги!")
    slow_print("Теперь ты настоящий Python-герой 🧙‍♂️🐍")

start_game()
